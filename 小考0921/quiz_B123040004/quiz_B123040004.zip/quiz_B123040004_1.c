#include<stdio.h>
int main()
{
	printf("I'm super shy, super shy\n");
	printf("But wait a minute while I make you mine~\n");
	printf("Y(^_^)Y");
}