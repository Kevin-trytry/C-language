#include<stdio.h>
int main()
{
	int a;
	printf("Please enter an integer(0~100):");
	scanf("%d",&a);
	if (a>=0 && a<=33)
		printf("You are in the LUCKY area");
	else if (a>=34 && a<=72)
		printf("You are in the GG area");
	else if (a>=73 && a<=100)
		printf("You are in the AWESOME area");
	else
		printf("Out of range");
 } 
