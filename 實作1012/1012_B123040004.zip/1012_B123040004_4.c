#include<stdio.h>
int main()
{
	int ch;
	while(ch!='Q' && ch!='q')
	{
		printf("Enter a character:");
		scanf("%c",&ch);
		switch(ch)
		{
		
			case 'A':
			case 'a':
				printf("Enter new mode\n");
				break;
			fflush(stdin);
			case 'D':
			case 'd':
				printf("Enter delete mode\n");
				break;
			fflush(stdin);
			case 'U':
			case 'u':
				printf("Enter mocification mode\n");
				break;
			fflush(stdin);
			case 'Q':
			case 'q':
				printf("Leave the system");
				break;
			fflush(stdin);
			default:
				printf("There is no such option!\n");
				break;
		}
		fflush(stdin);
			
	}
}
