#include<stdio.h>
int main()
{
	int year;
	printf("Enter the AD year:");
	scanf("%d",&year);
	if (year%4 !=0)
		printf("%d is not a leap yoer",year);
	else 
		{
			if (year%400==0)
				{
				printf("%d is the leap year",year);
		 		}
		 	else if (year%4==0)
		 		{
		 		printf("%d is the leap year",year);
				 }
		 	else
			 	{
		 		printf("%d is not the leap year",year);
				 }
		 }
		  
}
