#include<stdio.h>
int main()
{
	int num;
	printf("Please enter a two-digit number:");
	scanf("%d",&num);
	if (num/10==2)
		printf("In English :twenty");
	else if (num/10==3)
		printf("In English :thirty");	
	else if (num/10==4)
		printf("In English :fourty");
	else if (num/10==5)
		printf("In English :fifty");
	else if (num/10==6)
		printf("In English :sixty");
	else if (num/10==7)
		printf("In English :seventy");
	else if (num/10==8)
		printf("In English :eighty");
	else if (num/10==9)
		printf("In English :ninty");

	
	if (num%10==1)
		printf("-one");
	else if (num%10==2)
		printf("-two");
	else if (num%10==3)
		printf("-three");
	else if (num%10==4)
		printf("-four");
	else if (num%10==5)
		printf("-five");
	else if (num%10==6)
		printf("-six");
	else if (num%10==7)
		printf("-seven");
	else if (num%10==8)
		printf("-eight");
	else if (num%10==9)
		printf("-nine");

}

