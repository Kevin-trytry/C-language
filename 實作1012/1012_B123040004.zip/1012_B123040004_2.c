#include<stdio.h>
int main()
{
	int a;
	printf("Please enter an integer:");
	scanf("%d",&a);
	if (a>=0)
		printf("The absolute value of %d is:%d",a,a);
	else
		printf("The absolute value of %d is:%d",a,0-a);
}
