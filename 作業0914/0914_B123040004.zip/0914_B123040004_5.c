#include<stdio.h>
int main()
{
	int i=32767;
	short s=32767;
	printf("���i=%d\n", i);
	printf("�u���s=%d\n", s);
	printf("i+1=%d\n", i+1);
	printf("s+1=%hd\n",s+1);
}