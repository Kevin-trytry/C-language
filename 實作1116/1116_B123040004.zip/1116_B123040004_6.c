#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h> 
int main(){
	char buffer[1024];
	int i=0,j,length=0,max;
	while(fgets(buffer, 1024, stdin)){
		max=strlen(buffer);
		if(max>length)
		{
			length=max;
		}
	}
	printf("%s",buffer);
}
