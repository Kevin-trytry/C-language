#include<stdio.h>
int main()
{
	unsigned long long num;
	printf("Size of num is \\%dbytes\\ ",sizeof(num));
 } 
