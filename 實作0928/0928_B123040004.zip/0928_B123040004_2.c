#include<stdio.h>
int main()
{
	char ch;
	printf("Input a letter:");
	scanf("%c",&ch);
	printf("ASCII code of %c is %d",ch,ch);
}
